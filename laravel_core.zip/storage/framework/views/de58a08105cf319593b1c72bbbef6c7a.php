<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Pemindahan Aset</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

    <nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4 shadow">
        <div class="container">
            <a class="navbar-brand fw-bold" href="<?php echo e(route('dashboard.index')); ?>">Sistem Manajemen Aset</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link text-white" href="<?php echo e(route('aset.index')); ?>">Data Aset</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white fw-bold" href="<?php echo e(route('pemindahan_aset.index')); ?>">Pemindahan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="<?php echo e(route('laporan_kerusakan.index')); ?>">Laporan Kerusakan</a>
                    </li>
                </ul>
                <div class="d-flex align-items-center">
                    <span class="text-white me-3">👤 Halo, <?php echo e(auth()->user()->nama); ?></span>
                    <form action="<?php echo e(route('logout')); ?>" method="POST" class="m-0">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-sm btn-danger">Logout</button>
                    </form>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mb-5">
        <div class="card shadow">
            <div class="card-header bg-dark text-white d-flex justify-content-between align-items-center">
                <h4 class="mb-0">Riwayat Pemindahan Aset</h4>
                <?php if(auth()->user()->id_peran == 1): ?>
                    <a href="<?php echo e(route('pemindahan_aset.create')); ?>" class="btn btn-success btn-sm">+ Catat Pemindahan Baru</a>
                <?php endif; ?>
            </div>
            <div class="card-body">
                
                <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>

                <div class="table-responsive">
                    <table class="table table-bordered table-striped align-middle">
                        <thead class="table-dark text-center">
                            <tr>
                                <th>No</th>
                                <th>Nama Aset</th>
                                <th>Lokasi Awal</th>
                                <th>Lokasi Baru</th>
                                <th>Tanggal Pindah</th>
                                <th>Staf Pencatat</th> <th>Alasan</th>
                                <th>Status</th>
                                <?php if(auth()->user()->id_peran == 1): ?>
                                    <th>Aksi</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $pemindahans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="text-center"><?php echo e($index + 1); ?></td>
                                    
                                    <td class="fw-bold text-primary"><?php echo e($item->aset ? $item->aset->nama_aset : 'Aset Tidak Ditemukan'); ?></td>
                                    
                                    <td><?php echo e($item->lokasi_sebelumnya); ?></td>
                                    <td>
                                        <span class="badge bg-info text-dark"><?php echo e($item->lokasi_baru); ?></span>
                                    </td>
                                    <td class="text-center"><?php echo e(\Carbon\Carbon::parse($item->tgl_pindah)->format('d/m/Y')); ?></td>
                                    
                                    <td class="text-center">
                                        <?php if($item->pengguna): ?>
                                            <span class="fw-bold text-secondary"><?php echo e($item->pengguna->nama); ?></span>
                                        <?php else: ?>
                                            <span class="text-muted small">Tidak terdata</span>
                                        <?php endif; ?>
                                    </td>

                                    <td><?php echo e($item->alasan_pemindahan); ?></td>
                                    <td class="text-center"><?php echo e($item->status_aset); ?></td>
                                    
                                    <?php if(auth()->user()->id_peran == 1): ?>
                                    <td class="text-center">
                                        <form action="<?php echo e(route('pemindahan_aset.destroy', $item->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Yakin hapus riwayat pemindahan ini?')">Hapus</button>
                                        </form>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="9" class="text-center text-muted">Belum ada riwayat pemindahan aset.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>

</body>
</html><?php /**PATH C:\xampp\htdocs\rw-manajemen-asset\resources\views/pemindahan_aset/index.blade.php ENDPATH**/ ?>